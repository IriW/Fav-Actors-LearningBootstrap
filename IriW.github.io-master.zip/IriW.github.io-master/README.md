# IriW.github.io
Private Web Site Project

Another playground project.  
**My favourite actors of all times starting from childhood - PL**  
This is the project of web-page where I show my favourite actresses and actors (I'll never stop admiring them).   
I used Bootstrap for the 1st time in my life here :)  

Questions or suggestions in mind? Feel free to write me!
